<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrmDealAssigned extends Model
{
    protected $table = 'crm_deals_assigned';
    use HasFactory;
}
