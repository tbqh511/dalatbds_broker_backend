<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrmCustomerAddress extends Model
{
    protected $table = 'crm_customer_address';
    use HasFactory;
}
