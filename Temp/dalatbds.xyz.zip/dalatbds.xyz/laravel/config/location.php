<?php
//HuyTBQ
return [
    'district_code' => '672',
    'province_code' => '68'
];
