@extends('frontends.master')
@section('content')
<section class="parallax-section single-par color-bg">
    <div class="container">
        <div class="section-title center-align big-title">
            <h2><span>Tittle</span></h2>
            <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit amet fermentum
                sem.</h4>
        </div>
    </div>
    <div class="pwh_bg"></div>
    <div class="mrb_pin vis_mr mrb_pin3 "></div>
    <div class="mrb_pin vis_mr mrb_pin4 "></div>
</section>
@endsection
