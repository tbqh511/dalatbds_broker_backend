<section class="gray-bg ">
    <div class="container">
        <div class="section-title st-center fl-wrap">
            <h4>Đánh giá</h4>
            <h2>Khách hàng nói về Đà Lạt BDS</h2>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="testimonials-slider-wrap">
        <div class="testimonials-slider">
            <!--slick-item -->
            <div class="slick-item">
                <div class="text-carousel-item fl-wrap">
                    <div class="text-carousel-item-header fl-wrap">
                        <div class="popup-avatar"><img src="images/avatar/1.jpg" alt=""></div>
                        <div class="review-owner fl-wrap">Jessie Wilcox</div>
                        <div class="listing-rating card-popup-rainingvis" data-starrating2="5"> </div>
                    </div>
                    <div class="text-carousel-content fl-wrap">
                        <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus.
                            Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse
                            ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore
                            luptatum."</p>
                        <a href="#" class="testim-link color-bg">Via Facebook</a>
                    </div>
                </div>
            </div>
            <!--slick-item end -->
            <!--slick-item -->
            <div class="slick-item">
                <div class="text-carousel-item fl-wrap">
                    <div class="text-carousel-item-header fl-wrap">
                        <div class="popup-avatar"><img src="images/avatar/1.jpg" alt=""></div>
                        <div class="review-owner fl-wrap">Austin Harisson</div>
                        <div class="listing-rating card-popup-rainingvis" data-starrating2="4"> </div>
                    </div>
                    <div class="text-carousel-content fl-wrap">
                        <p> "Feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit
                            praesent luptatum zzril delenit augue duis dolore te odio dignissim qui blandit praesent
                            blandit praesent luptatum zzril.Vulputate urna. Nulla tristique mi a massa convallis."
                        </p>
                        <a href="#" class="testim-link color-bg">Via Twitter</a>
                    </div>
                </div>
            </div>
            <!--slick-item end -->
            <!--slick-item -->
            <div class="slick-item">
                <div class="text-carousel-item fl-wrap">
                    <div class="text-carousel-item-header fl-wrap">
                        <div class="popup-avatar"><img src="images/avatar/1.jpg" alt=""></div>
                        <div class="review-owner fl-wrap">Garry Colonsi</div>
                        <div class="listing-rating card-popup-rainingvis" data-starrating2="4"> </div>
                    </div>
                    <div class="text-carousel-content fl-wrap">
                        <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus.
                            Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse
                            ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore
                            luptatum."</p>
                        <a href="#" class="testim-link color-bg">Via Facebook</a>
                    </div>
                </div>
            </div>
            <!--slick-item end -->
            <!--slick-item -->
            <div class="slick-item">
                <div class="text-carousel-item fl-wrap">
                    <div class="text-carousel-item-header fl-wrap">
                        <div class="popup-avatar"><img src="images/avatar/1.jpg" alt=""></div>
                        <div class="review-owner fl-wrap">Antony Moore</div>
                        <div class="listing-rating card-popup-rainingvis" data-starrating2="5"> </div>
                    </div>
                    <div class="text-carousel-content fl-wrap">
                        <p> "Feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit
                            praesent luptatum zzril delenit augue duis dolore te odio dignissim qui blandit praesent
                            blandit praesent luptatum zzril.Vulputate urna. Nulla tristique mi a massa convallis."
                        </p>
                        <a href="#" class="testim-link color-bg">Via Twitter</a>
                    </div>
                </div>
            </div>
            <!--slick-item end -->
        </div>
    </div>
</section>
