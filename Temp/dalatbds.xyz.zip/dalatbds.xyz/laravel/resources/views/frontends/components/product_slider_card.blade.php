<div class="slick-slide-item">
    <div class="box-item">
        <img src="{{asset('images/bg/1.jpg')}}" alt="">
        <a href="{{asset('images/bg/1.jpg')}}" class="gal-link popup-image"><i class="fal fa-search"></i></a>
        <div class="show-info">
            <span><i class="fas fa-info"></i></span>
            <div class="tooltip-info">
                <h5>Room Details</h5>
                <p>Sed non nisi viverra, porttitor sem nec, vestibulum justo tortor ornare turpis faucibus
                </p>
            </div>
        </div>
    </div>
</div>
