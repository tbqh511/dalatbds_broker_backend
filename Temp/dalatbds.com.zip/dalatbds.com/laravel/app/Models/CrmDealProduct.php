<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrmDealProduct extends Model
{
    protected $table = 'crm_deals_products';
    use HasFactory;
}
