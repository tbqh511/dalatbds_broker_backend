<div class="slick-item">
    <div class="half-carousel-item fl-wrap">
        <div class="bg-wrap bg-parallax-wrap-gradien">
            <div class="bg" data-bg="/images/bg/phuong1.jpg"></div>
        </div>
        <div class="half-carousel-content">
            <a href="/nha-ban" class="hc-counter small-btn color-bg">26 BĐS đang giao dịch</a>
            <h3><a href="listing.html">Phường 1</a></h3>
        </div>
    </div>
</div>
